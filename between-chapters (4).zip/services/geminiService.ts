
import { GoogleGenAI, Type } from "@google/genai";
import { IntakeData, AssessmentResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export async function generateTransitionAnalysis(data: IntakeData): Promise<AssessmentResult> {
  const prompt = `
    Analyze this life transition for ${data.name}. 
    Context:
    - Focus: ${data.unsettledArea.join(', ')}
    - Feel: ${data.transitionFeeling}
    - Emotions: ${data.emotions.join(', ')}
    - Support: ${data.supportSystem}
    - Hardest part: ${data.hardestToSay}
    - Fear: ${data.fearOfLosing}
    - Progress vision: ${data.sixMonthVision}

    Goal: Help the user understand their current "in-between" chapter. 
    Tone: Concise, plain language, insightful, and supportive. Avoid coaching jargon or flowery descriptions. Be definitive—don't say "it seems" or "you might be." 
    Constraint: NO em dashes (—) or en dashes (–). 

    Specific Resource Requirements:
    - 1 HBR article tied to: ${data.unsettledArea.join(', ')}.
    - 1 helpful book for this transition.
    - 1 free course or tool (Udemy, Coursera, etc).

    Structure:
    1. Chapter Name: 3-5 words max.
    2. Description: 250-300 words. Plain, accessible language.
    3. 4 requirements for this chapter.
    4. 90-day pathway (Month 1, 2, 3) with 2-3 clear bullets each.
    5. The 3 specific resources (Article, Book, Course).
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          chapterName: { type: Type.STRING },
          elegantDescription: { type: Type.STRING },
          chapterRequirements: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          pathway: {
            type: Type.OBJECT,
            properties: {
              month1: { type: Type.ARRAY, items: { type: Type.STRING } },
              month2: { type: Type.ARRAY, items: { type: Type.STRING } },
              month3: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["month1", "month2", "month3"]
          },
          resources: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                type: { type: Type.STRING },
                source: { type: Type.STRING },
                title: { type: Type.STRING },
                link: { type: Type.STRING }
              },
              required: ["type", "source", "title", "link"]
            }
          }
        },
        required: ["chapterName", "elegantDescription", "chapterRequirements", "pathway", "resources"]
      }
    }
  });

  return JSON.parse(response.text.trim());
}
