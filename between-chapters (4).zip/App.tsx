
import React, { useState } from 'react';
import Hero from './components/Hero';
import IntakeForm from './components/IntakeForm';
import LoadingScreen from './components/LoadingScreen';
import ResultView from './components/ResultView';
import { IntakeData, AssessmentResult } from './types';
import { generateTransitionAnalysis } from './services/geminiService';

type View = 'Home' | 'Intake' | 'Loading' | 'Result';

const App: React.FC = () => {
  const [view, setView] = useState<View>('Home');
  const [userData, setUserData] = useState<IntakeData | null>(null);
  const [result, setResult] = useState<AssessmentResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleStart = () => {
    setView('Intake');
  };

  const handleIntakeSubmit = async (data: IntakeData) => {
    setUserData(data);
    setView('Loading');
    try {
      const analysis = await generateTransitionAnalysis(data);
      setResult(analysis);
      setView('Result');
    } catch (err) {
      console.error(err);
      setError("We encountered an issue generating your insights. Please try again.");
      setView('Intake');
    }
  };

  const handleReset = () => {
    setView('Home');
    setUserData(null);
    setResult(null);
    setError(null);
  };

  return (
    <div className="min-h-screen selection:bg-sky-100 selection:text-sky-900">
      {/* Global Navigation - Minimal */}
      <nav className="fixed top-0 w-full z-40 px-6 py-6 flex justify-between items-center pointer-events-none">
        <div className="pointer-events-auto cursor-pointer" onClick={handleReset}>
          <span className="text-xl serif font-bold tracking-tight text-slate-950">Between Chapters</span>
        </div>
        {view === 'Home' && (
          <div className="pointer-events-auto">
             <button 
              onClick={handleStart}
              className="text-sm font-medium text-slate-500 hover:text-slate-950 transition-colors"
            >
              Start Reflection
            </button>
          </div>
        )}
      </nav>

      <main className="relative pt-10">
        {error && (
          <div className="max-w-md mx-auto mt-20 p-4 bg-red-50 border border-red-100 text-red-600 rounded-xl text-center">
            {error}
          </div>
        )}

        {view === 'Home' && <Hero onStart={handleStart} />}
        {view === 'Intake' && <IntakeForm onSubmit={handleIntakeSubmit} />}
        {view === 'Loading' && <LoadingScreen />}
        {view === 'Result' && result && userData && (
          <ResultView 
            data={userData} 
            result={result} 
            onReset={handleReset}
          />
        )}
      </main>

      <footer className="py-12 border-t border-slate-100 text-center">
        <p className="text-xs text-slate-400 font-medium tracking-[0.1em] uppercase">
          &copy; {new Date().getFullYear()} Between Chapters. Built for transitions.
        </p>
      </footer>
    </div>
  );
};

export default App;
