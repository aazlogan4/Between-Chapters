
export type Gender = 'Male' | 'Female' | 'Non-binary' | 'Prefer not to say';

export interface IntakeData {
  name: string;
  email: string;
  gender: Gender;
  unsettledArea: string[];
  transitionFeeling: string;
  emotions: string[];
  supportSystem: string;
  hardestToSay: string;
  fearOfLosing: string;
  underusedParts: string;
  sixMonthVision: string;
  uncertaintyResponse: string[];
  resistedSupport: string;
}

export interface Resource {
  type: 'Article' | 'Book' | 'Course';
  source: string;
  title: string;
  link: string;
}

export interface AssessmentResult {
  chapterName: string;
  elegantDescription: string;
  chapterRequirements: string[];
  pathway: {
    month1: string[];
    month2: string[];
    month3: string[];
  };
  resources: Resource[];
}
