
import React from 'react';

interface HeroProps {
  onStart: () => void;
}

const Hero: React.FC<HeroProps> = ({ onStart }) => {
  return (
    <div className="max-w-6xl mx-auto px-6 pt-20 pb-16 md:pt-32 md:pb-24">
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div className="space-y-4">
            <h1 className="text-5xl md:text-7xl serif font-medium leading-tight text-slate-950">
              You’re not lost.<br />
              <span className="italic text-sky-500">Just in between chapters.</span>
            </h1>
            <p className="text-xl text-slate-600 font-light leading-relaxed max-w-xl">
              I study how people navigate life changes and friendship. I build tools to help you make sense of change without the rush.
            </p>
          </div>
          
          <div className="space-y-4">
            <button 
              onClick={onStart}
              className="inline-flex items-center px-8 py-4 bg-slate-950 text-white font-medium rounded-full shadow-lg hover:shadow-sky-200/50 hover:bg-slate-800 transition-all duration-300 group"
            >
              <span className="mr-2">Identify Your Current Chapter</span>
              <span className="text-sky-400 group-hover:translate-x-1 transition-transform">👉</span>
            </button>
            <p className="text-sm text-slate-500 italic max-w-sm leading-relaxed">
              "This is not a diagnosis. It’s a reflection to help you name what you’re already carrying."
            </p>
          </div>
        </div>
        
        <div className="bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-slate-100 space-y-6">
          <h2 className="text-2xl serif font-medium text-slate-950">What This Is</h2>
          <div className="space-y-4 text-slate-600 leading-relaxed">
            <p>
              Change is hard because no one teaches us how to be "in-between." This work focuses on that gap: who you were versus who you are becoming.
            </p>
            <ul className="space-y-3">
              {[
                "Personal transitions",
                "Friendship and connection",
                "Identity beyond your title",
                "The quiet shifts no one sees"
              ].map((item, i) => (
                <li key={i} className="flex items-center space-x-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-sky-400"></span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
