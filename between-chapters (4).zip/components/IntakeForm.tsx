
import React, { useState } from 'react';
import { IntakeData, Gender } from '../types';

interface IntakeFormProps {
  onSubmit: (data: IntakeData) => void;
}

const IntakeForm: React.FC<IntakeFormProps> = ({ onSubmit }) => {
  const [step, setStep] = useState(0);
  const [formData, setFormData] = useState<Partial<IntakeData>>({
    unsettledArea: [],
    emotions: [],
    uncertaintyResponse: [],
  });

  const nextStep = () => setStep(s => s + 1);
  const prevStep = () => setStep(s => s - 1);

  const updateField = (field: keyof IntakeData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleArrayField = (field: 'unsettledArea' | 'emotions' | 'uncertaintyResponse', value: string) => {
    const current = (formData[field] as string[]) || [];
    if (current.includes(value)) {
      updateField(field, current.filter(item => item !== value));
    } else {
      updateField(field, [...current, value]);
    }
  };

  const steps = [
    // Step 1: Basics
    {
      title: "Tell me about you",
      content: (
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">First Name</label>
            <input 
              type="text" 
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-100 focus:border-sky-400 outline-none transition-all"
              placeholder="Your name"
              value={formData.name || ''}
              onChange={(e) => updateField('name', e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Email Address</label>
            <input 
              type="email" 
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-100 focus:border-sky-400 outline-none transition-all"
              placeholder="you@example.com"
              value={formData.email || ''}
              onChange={(e) => updateField('email', e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Gender</label>
            <div className="grid grid-cols-2 gap-3">
              {['Male', 'Female', 'Non-binary', 'Prefer not to say'].map(g => (
                <button
                  key={g}
                  onClick={() => updateField('gender', g as Gender)}
                  className={`px-4 py-3 rounded-xl border text-sm transition-all ${
                    formData.gender === g 
                    ? 'border-sky-400 bg-sky-50 text-sky-700' 
                    : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>
          <div className="pt-4 border-t border-slate-100">
            <p className="text-xs text-slate-400 leading-relaxed italic">
              Your information is only used to personalize this intake and provide relevant insights. You will not be contacted or added to any lists unless you explicitly choose to later in this process.
            </p>
          </div>
        </div>
      )
    },
    // Step 2: Areas of Life
    {
      title: "Which area of life feels most unsettled right now?",
      subtitle: "Select all that apply",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {['Work / Identity', 'Relationships / Friendship', 'Family or Parenting', 'Loss or Grief', 'Success or Plateau', 'Something I can’t quite name'].map(item => (
            <button
              key={item}
              onClick={() => toggleArrayField('unsettledArea', item)}
              className={`px-4 py-4 rounded-xl border text-left text-sm transition-all ${
                formData.unsettledArea?.includes(item)
                ? 'border-sky-400 bg-sky-50 text-sky-700 ring-2 ring-sky-50'
                : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              {item}
            </button>
          ))}
        </div>
      )
    },
    // Step 3: Feeling of Transition
    {
      title: "Does this transition feel:",
      content: (
        <div className="space-y-3">
          {['Chosen', 'Imposed', 'A slow realization', 'A sudden shift'].map(item => (
            <button
              key={item}
              onClick={() => updateField('transitionFeeling', item)}
              className={`w-full px-4 py-4 rounded-xl border text-left text-sm transition-all ${
                formData.transitionFeeling === item
                ? 'border-sky-400 bg-sky-50 text-sky-700 ring-2 ring-sky-50'
                : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              {item}
            </button>
          ))}
        </div>
      )
    },
    // Step 4: Emotions
    {
      title: "What emotions show up most often lately?",
      subtitle: "Select all that apply",
      content: (
        <div className="grid grid-cols-2 gap-3">
          {['Restlessness', 'Sadness', 'Irritation', 'Numbness', 'Hope mixed with fear'].map(item => (
            <button
              key={item}
              onClick={() => toggleArrayField('emotions', item)}
              className={`px-4 py-4 rounded-xl border text-left text-sm transition-all ${
                formData.emotions?.includes(item)
                ? 'border-sky-400 bg-sky-50 text-sky-700 ring-2 ring-sky-50'
                : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              {item}
            </button>
          ))}
        </div>
      )
    },
    // Step 5: Support
    {
      title: "Who do you currently talk to about this?",
      content: (
        <div className="space-y-3">
          {['No one', 'A partner', 'Friends (but not deeply)', 'A small trusted circle'].map(item => (
            <button
              key={item}
              onClick={() => updateField('supportSystem', item)}
              className={`w-full px-4 py-4 rounded-xl border text-left text-sm transition-all ${
                formData.supportSystem === item
                ? 'border-sky-400 bg-sky-50 text-sky-700 ring-2 ring-sky-50'
                : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              {item}
            </button>
          ))}
        </div>
      )
    },
    // Step 6: Qualitative 1
    {
      title: "What feels hardest to say out loud?",
      content: (
        <textarea
          className="w-full h-32 px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-100 focus:border-sky-400 outline-none transition-all"
          placeholder="Share as much or as little as you'd like..."
          value={formData.hardestToSay || ''}
          onChange={(e) => updateField('hardestToSay', e.target.value)}
        />
      )
    },
    // Step 7: Qualitative 2
    {
      title: "What are you most afraid of losing right now?",
      content: (
        <textarea
          className="w-full h-32 px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-100 focus:border-sky-400 outline-none transition-all"
          placeholder="..."
          value={formData.fearOfLosing || ''}
          onChange={(e) => updateField('fearOfLosing', e.target.value)}
        />
      )
    },
    // Step 8: Qualitative 3
    {
      title: "What part of yourself feels underused, overused or unseen?",
      content: (
        <textarea
          className="w-full h-32 px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-100 focus:border-sky-400 outline-none transition-all"
          placeholder="..."
          value={formData.underusedParts || ''}
          onChange={(e) => updateField('underusedParts', e.target.value)}
        />
      )
    },
    // Step 9: 6-month progress
    {
      title: "When you imagine 6 months from now, what would feel like progress?",
      content: (
        <textarea
          className="w-full h-32 px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-100 focus:border-sky-400 outline-none transition-all"
          placeholder="..."
          value={formData.sixMonthVision || ''}
          onChange={(e) => updateField('sixMonthVision', e.target.value)}
        />
      )
    },
    // Step 10: Uncertainty & Resisted Support
    {
      title: "How do you usually respond to uncertainty?",
      content: (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-3">
            {['Analyze', 'Distract', 'Withdraw', 'Stay busy', 'Talk it through'].map(item => (
              <button
                key={item}
                onClick={() => toggleArrayField('uncertaintyResponse', item)}
                className={`px-4 py-4 rounded-xl border text-left text-sm transition-all ${
                  formData.uncertaintyResponse?.includes(item)
                  ? 'border-sky-400 bg-sky-50 text-sky-700 ring-2 ring-sky-50'
                  : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                {item}
              </button>
            ))}
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">What kind of support do you tend to resist, even if it helps?</label>
            <input 
              type="text" 
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-sky-100 focus:border-sky-400 outline-none transition-all"
              placeholder="..."
              value={formData.resistedSupport || ''}
              onChange={(e) => updateField('resistedSupport', e.target.value)}
            />
          </div>
        </div>
      )
    },
  ];

  const currentStepData = steps[step];
  const isLastStep = step === steps.length - 1;
  const isFirstStep = step === 0;

  const canProceed = () => {
    if (step === 0) return formData.name && formData.email && formData.gender;
    if (step === 1) return (formData.unsettledArea?.length || 0) > 0;
    if (step === 2) return !!formData.transitionFeeling;
    if (step === 3) return (formData.emotions?.length || 0) > 0;
    if (step === 4) return !!formData.supportSystem;
    if (step >= 5 && step <= 9) return true; // Optional qualitative text, but better if provided
    return true;
  };

  const handleSubmit = () => {
    if (canProceed()) {
      onSubmit(formData as IntakeData);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-6 py-20">
      <div className="mb-12">
        <div className="flex justify-between items-center mb-4">
          <span className="text-sm font-medium text-sky-600 uppercase tracking-widest">Question {step + 1} of {steps.length}</span>
          <div className="flex space-x-1">
            {steps.map((_, i) => (
              <div key={i} className={`h-1 w-6 rounded-full transition-all ${i <= step ? 'bg-sky-400' : 'bg-slate-200'}`} />
            ))}
          </div>
        </div>
        <h2 className="text-3xl md:text-4xl serif font-medium text-slate-950 mb-4">{currentStepData.title}</h2>
        {currentStepData.subtitle && <p className="text-slate-500 mb-6">{currentStepData.subtitle}</p>}
      </div>

      <div className="min-h-[300px]">
        {currentStepData.content}
      </div>

      <div className="mt-12 flex justify-between items-center">
        {!isFirstStep && (
          <button 
            onClick={prevStep}
            className="px-6 py-3 text-slate-500 hover:text-slate-950 transition-colors font-medium"
          >
            Previous
          </button>
        )}
        <div className="ml-auto">
          {isLastStep ? (
            <button 
              onClick={handleSubmit}
              disabled={!canProceed()}
              className="px-10 py-4 bg-slate-950 text-white rounded-full font-medium hover:bg-slate-800 disabled:opacity-50 transition-all shadow-lg"
            >
              Analyze My Results
            </button>
          ) : (
            <button 
              onClick={nextStep}
              disabled={!canProceed()}
              className="px-10 py-4 bg-slate-950 text-white rounded-full font-medium hover:bg-slate-800 disabled:opacity-50 transition-all shadow-lg"
            >
              Next
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default IntakeForm;
