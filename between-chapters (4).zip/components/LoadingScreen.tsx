
import React, { useState, useEffect } from 'react';

const messages = [
  "Structuring your reflections...",
  "Synthesizing your insights...",
  "Looking for the language you need...",
  "Identifying your current chapter...",
  "Nearly there. Honor the pause."
];

const LoadingScreen: React.FC = () => {
  const [msgIndex, setMsgIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setMsgIndex((prev) => (prev + 1) % messages.length);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 bg-white flex flex-col items-center justify-center p-6 text-center z-50">
      <div className="w-16 h-16 border-2 border-sky-100 border-t-sky-500 rounded-full animate-spin mb-8"></div>
      <h3 className="text-2xl serif italic text-slate-900 mb-2 transition-all duration-500">
        {messages[msgIndex]}
      </h3>
      <p className="text-slate-400 font-light">
        Transitions take time. We’re giving your responses the attention they deserve.
      </p>
    </div>
  );
};

export default LoadingScreen;
