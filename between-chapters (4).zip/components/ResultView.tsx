
import React from 'react';
import { IntakeData, AssessmentResult } from '../types';

interface ResultViewProps {
  data: IntakeData;
  result: AssessmentResult;
  onReset: () => void;
}

const ResultView: React.FC<ResultViewProps> = ({ data, result, onReset }) => {
  const isFemale = data.gender === 'Female';
  const isMale = data.gender === 'Male';
  const hasFriendshipStruggle = data.unsettledArea.some(a => a.toLowerCase().includes('friendship')) || data.supportSystem === 'No one';

  const handleEmailJournal = () => {
    const subject = encodeURIComponent("My Reflection Journal - Between Chapters");
    const body = encodeURIComponent(`Hello ${data.name},\n\nHere is a prompt for your current chapter: ${result.chapterName}.\n\n"If you didn't have to fix this transition right now, what is the one thing your current self would say to your future self about this space?"\n\nTake your time with this.\n\nBest,\nBetween Chapters`);
    window.location.href = `mailto:${data.email}?subject=${subject}&body=${body}`;
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-16 space-y-20">
      {/* 1. Definitive Chapter Header */}
      <div className="space-y-6 text-center">
        <span className="text-sm font-medium text-sky-600 uppercase tracking-[0.2em]">The Transition Index</span>
        <h1 className="text-5xl md:text-6xl serif font-medium text-slate-950">
          Your Chapter: <br />
          <span className="italic text-sky-500">{result.chapterName}</span>
        </h1>
        <div className="w-24 h-1 bg-slate-200 mx-auto rounded-full"></div>
      </div>

      {/* 2. Accessible Description */}
      <section className="bg-white p-8 md:p-12 rounded-[32px] shadow-sm border border-slate-100">
        <h2 className="text-2xl serif font-medium text-slate-950 mb-6">Naming the Chapter</h2>
        <div className="prose prose-slate max-w-none text-slate-600 leading-[1.7] space-y-4">
          {result.elegantDescription.split('\n\n').map((para, i) => (
            <p key={i}>{para}</p>
          ))}
        </div>
      </section>

      {/* 3. Requirements */}
      <section className="space-y-8">
        <h2 className="text-3xl serif font-medium text-slate-950">What This Requires</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          {result.chapterRequirements.map((req, i) => (
            <div key={i} className="flex items-center space-x-4 p-5 bg-white rounded-2xl border border-slate-100 shadow-sm">
              <span className="flex-shrink-0 w-6 h-6 rounded-full bg-sky-50 text-sky-500 flex items-center justify-center font-bold text-xs">
                {i + 1}
              </span>
              <p className="text-slate-700 text-sm font-medium leading-relaxed">{req}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Pathway */}
      <section className="space-y-12">
        <h2 className="text-3xl serif font-medium text-slate-950">A 90-Day Path</h2>
        <div className="space-y-12">
          {['Month 1 – Stabilize', 'Month 2 – Reconnect', 'Month 3 – Reorient'].map((title, idx) => {
            const key = `month${idx + 1}` as keyof typeof result.pathway;
            return (
              <div key={title} className="relative pl-8 border-l-2 border-slate-100">
                <div className="absolute top-0 -left-[9px] w-4 h-4 rounded-full bg-slate-950 ring-4 ring-white"></div>
                <h3 className="text-xl font-medium text-slate-950 mb-4">{title}</h3>
                <ul className="space-y-3">
                  {result.pathway[key].map((item, i) => (
                    <li key={i} className="flex items-start space-x-3 text-slate-600 text-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-sky-400 mt-1.5 flex-shrink-0"></span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </section>

      {/* 5. Ways to Navigate (Coaching Soft-sell) */}
      <section className="pt-10 border-t border-slate-100">
        <h2 className="text-2xl serif font-medium text-slate-950 mb-8">How to Move Forward</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="p-8 bg-slate-50 border border-slate-100 rounded-3xl space-y-4">
            <h4 className="font-medium text-slate-900">Research Group</h4>
            <p className="text-sm text-slate-500">Dialogue with others in similar transitions.</p>
            <button 
              onClick={() => window.location.href = "mailto:aazlogan@gmail.com?subject=Interested in Research Group"}
              className="inline-block text-sm font-bold text-sky-600 hover:text-sky-700"
            >
              Express Interest →
            </button>
          </div>
          <div className="p-8 bg-sky-900 text-white rounded-3xl space-y-4">
            <h4 className="font-medium">Supported Conversations</h4>
            <p className="text-sm text-sky-200">One-on-one dialogue with a neutral guide.</p>
            <a href="https://calendly.com/azlogan/45mins" target="_blank" className="inline-block text-sm font-bold text-sky-400 hover:text-sky-300">
              Book a 45-min Session →
            </a>
          </div>
        </div>
      </section>

      {/* 6. Recommended Reading & Resources (At bottom as requested) */}
      <section className="space-y-8 pt-10 border-t border-slate-100">
        <h2 className="text-3xl serif font-medium text-slate-950">Recommended Resources</h2>
        
        <div className="grid md:grid-cols-2 gap-8">
          {/* Targeted HBR/Books */}
          <div className="bg-white border border-slate-100 p-8 rounded-[32px] space-y-6 shadow-sm">
            <h3 className="text-xl serif italic">For Your Specific Focus</h3>
            <div className="space-y-4">
              {result.resources.map((res, i) => (
                <div key={i} className="group">
                  <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">{res.source} • {res.type}</p>
                  <a href={res.link} target="_blank" rel="noopener noreferrer" className="block text-sm text-sky-600 hover:underline font-medium">
                    {res.title}
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* Author's Personal Books/Invites */}
          <div className="bg-slate-950 text-white p-8 rounded-[32px] flex flex-col justify-between">
            <div>
              <h3 className="text-xl serif italic mb-4">A Note on Connection</h3>
              {isMale ? (
                <p className="text-slate-400 text-sm leading-relaxed mb-6">
                  I'm writing a book on male friendship. I'd love for you to join an Insights Session to share your perspective.
                </p>
              ) : (
                <p className="text-slate-400 text-sm leading-relaxed mb-6">
                  Female friendships are an anchor in transition. "Invisible Threads" celebrates these powerful connections.
                </p>
              )}
            </div>
            <a 
              href={isFemale ? "https://a.co/d/0trqTu3" : "mailto:aazlogan@gmail.com?subject=Insights Session - Male Friendship"} 
              target={isFemale ? "_blank" : undefined}
              className="inline-block text-sky-400 font-bold hover:text-sky-300 transition-colors"
            >
              {isMale ? "Join the Insights Session →" : "View 'Invisible Threads' →"}
            </a>
          </div>
        </div>

        {hasFriendshipStruggle && (
           <div className="bg-sky-50 border border-sky-100 p-6 rounded-2xl flex items-center justify-between">
            <p className="text-sky-800 text-sm italic">
              Friendship feels unsettled right now. Remember: transitions are lonelier when carried alone.
            </p>
            <a href="https://a.co/d/0trqTu3" target="_blank" className="text-sky-700 font-bold text-sm whitespace-nowrap ml-4 underline underline-offset-4">
              Friendship Resources
            </a>
           </div>
        )}
      </section>

      {/* 7. Journaling Reflection */}
      <div className="py-16 bg-slate-50 rounded-[48px] text-center px-6">
        <h3 className="text-2xl serif font-medium mb-4">Your Custom Reflection</h3>
        <p className="text-slate-600 mb-8 max-w-lg mx-auto text-sm leading-relaxed">
          Ready to go deeper? I've prepared a custom journal prompt specifically for your {result.chapterName} chapter.
        </p>
        <button 
          onClick={handleEmailJournal}
          className="px-8 py-3 bg-slate-950 text-white rounded-full font-medium hover:bg-slate-800 transition-all shadow-lg"
        >
          Email Me the Prompt
        </button>
      </div>

      <div className="text-center pt-10">
        <button onClick={onReset} className="text-xs text-slate-400 hover:text-slate-600 font-medium uppercase tracking-widest">
          Start Over
        </button>
      </div>
    </div>
  );
};

export default ResultView;
