
import { GoogleGenAI } from "@google/genai";
import { UserAnswers } from "../types";

export const getTransitionInsight = async (answers: UserAnswers): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const formattedAnswers = Object.entries(answers)
    .map(([key, value]) => `- ${key}: ${Array.isArray(value) ? value.join(', ') : value}`)
    .join('\n');

  const prompt = `
    I am going through a life transition. Here are my reflection details:
    ${formattedAnswers}
    
    Please provide a structured response with exactly these 4 sections, formatted with clear headings.
    IMPORTANT: Do NOT use em dashes (—) in your output. Use commas (,) instead.

    ### Section 1: Naming the Chapter
    Give this chapter a poetic and accurate name (e.g., "The Quiet Rebuild", "The Threshold of No Return").
    Provide a short, elegant description (300–400 words) that offers recognition and insight. 

    ### Section 2: What This Chapter Often Requires
    Provide 3-4 bullet points of what this specific state needs.

    ### Section 3: A 90-Day Personal Pathway
    Format this section strictly as follows so it can be rendered as a checklist:
    - Month 1: [Task Name]: [Actionable description]
    - Month 2: [Task Name]: [Actionable description]
    - Month 3: [Task Name]: [Actionable description]

    ### Section 4: Ways People Navigate This Chapter
    Describe common ways people move through this chapter briefly.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        systemInstruction: `You are an empathetic life transition guide. Your tone is calm, wise, and professional. 
        Focus on insight and naming the experience. 
        In Section 3, ensure the tasks are practical and actionable behaviors.
        IMPORTANT: NEVER use em dashes (—) in your response. Replace them with commas.`,
        temperature: 0.75,
      },
    });

    return response.text || "Connection failed. Please take a deep breath and try again.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate insight.");
  }
};
