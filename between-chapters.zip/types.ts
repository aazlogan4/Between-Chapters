
export type QuestionType = 'text' | 'choice' | 'multi-choice';

export interface Question {
  id: string;
  label: string;
  type: QuestionType;
  placeholder?: string;
  options?: string[];
}

export interface UserAnswers {
  [key: string]: string | string[];
}

export enum AppState {
  WELCOME = 'WELCOME',
  SURVEY = 'SURVEY',
  LOADING = 'LOADING',
  RESULT = 'RESULT'
}
