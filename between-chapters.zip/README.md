# Between Chapters: The Life Transition Index

**Between Chapters** is a structured reflection tool designed for individuals navigating major life transitions, identity shifts, and the "space between."

## 🌟 Vision
Most people struggle during change because they lack the language to describe it. This application provides a safe, poetic, and practical container to name your current chapter and map a meaningful way forward.

## 🚀 Quick Start
To run this locally:
1. `npm install`
2. `npm run dev`

## 📱 Hosting as an App
The easiest way to make this "live" is using **Vercel**:

1. **GitHub**: Upload these files to a new repository.
2. **Deploy**: Connect the repo to [Vercel](https://vercel.com).
3. **API Key**: Add your Gemini API key as an environment variable named `API_KEY` in Vercel settings.
4. **Mobile App**: Once live, open the URL in your mobile browser and select **"Add to Home Screen"** to install it as a standalone app.

## 🛠️ Tech Stack
- **React 19** & **Tailwind CSS**
- **Google Gemini 3.0 Pro** for narrative synthesis.
- **ESM.sh** for ultra-fast, buildless module loading.

---
*Created to help you put language to change, without rushing it.*
