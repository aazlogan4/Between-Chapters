
import React from 'react';

interface WelcomeViewProps {
  onStart: () => void;
}

const WelcomeView: React.FC<WelcomeViewProps> = ({ onStart }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[85vh] text-center px-6 py-12">
      <div className="max-w-3xl w-full">
        <h1 className="text-4xl md:text-7xl font-serif text-black mb-8 leading-tight tracking-tight">
          You’re not lost.<br />
          <span className="italic text-[#0ea5e9]">You’re in between chapters.</span>
        </h1>
        
        <div className="text-left space-y-6 text-slate-600 text-lg md:text-xl leading-relaxed mb-8">
          <p>
            I study how people navigate life transitions, identity shifts, and modern friendship, and I build tools to help people make sense of change without rushing it.
          </p>
          <p>
            Most people don’t struggle because they lack ambition or resilience. They struggle because no one taught them how to navigate the space between who they were and who they’re becoming.
          </p>
        </div>

        {/* Focus Areas Box */}
        <div className="bg-white border border-slate-100 rounded-3xl p-8 mb-10 shadow-sm shadow-sky-100/50">
          <p className="font-serif text-xl text-black italic mb-6">
            This work lives in that space:
          </p>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-y-4 gap-x-8 text-left text-slate-600 text-base md:text-lg">
            <li className="flex items-start">
              <span className="text-[#0ea5e9] mr-2 font-bold">•</span> Personal transitions
            </li>
            <li className="flex items-start">
              <span className="text-[#0ea5e9] mr-2 font-bold">•</span> Friendship and connection
            </li>
            <li className="flex items-start">
              <span className="text-[#0ea5e9] mr-2 font-bold">•</span> Identity beyond roles and titles
            </li>
            <li className="flex items-start">
              <span className="text-[#0ea5e9] mr-2 font-bold">•</span> The quiet, unspoken shifts
            </li>
          </ul>
        </div>

        {/* CTA Button */}
        <div className="flex flex-col items-center space-y-4 mb-8">
          <button
            onClick={onStart}
            className="group relative bg-black hover:bg-[#0ea5e9] text-white font-medium py-5 px-12 rounded-full transition-all duration-500 transform hover:scale-105 shadow-xl overflow-hidden flex items-center justify-center space-x-3"
          >
            <span className="relative z-10 text-lg">Identify Your Current Chapter</span>
            <svg 
              className="relative z-10 w-5 h-5 text-[#0ea5e9] group-hover:text-white transition-colors duration-500" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
            <div className="absolute inset-0 bg-[#0284c7] transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-500"></div>
          </button>
          <p className="text-xs text-slate-400 uppercase tracking-widest pt-2 font-medium">
            The Life Transition Index
          </p>
        </div>

        {/* Disclaimer Box */}
        <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 max-w-2xl mx-auto">
          <p className="text-slate-500 text-sm md:text-base italic leading-relaxed">
            "This is not a diagnosis. It’s a structured reflection designed to help you put language to what you’re already carrying."
          </p>
        </div>
      </div>
    </div>
  );
};

export default WelcomeView;
