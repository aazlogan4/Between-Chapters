
import React, { useState } from 'react';
import { UserAnswers } from '../types';

interface ResultViewProps {
  insight: string;
  onReset: () => void;
  answers: UserAnswers;
}

const ChecklistItem: React.FC<{ text: string }> = ({ text }) => {
  const [checked, setChecked] = useState(false);
  return (
    <div 
      onClick={() => setChecked(!checked)}
      className={`flex items-start p-4 rounded-xl border transition-all cursor-pointer mb-3 ${
        checked ? 'bg-sky-50 border-sky-200' : 'bg-white border-slate-100 hover:border-sky-100'
      }`}
    >
      <div className={`mt-1 w-5 h-5 rounded border flex-shrink-0 flex items-center justify-center transition-colors ${
        checked ? 'bg-[#0ea5e9] border-[#0ea5e9]' : 'border-slate-300'
      }`}>
        {checked && (
          <svg className="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
          </svg>
        )}
      </div>
      <span className={`ml-4 text-lg ${checked ? 'text-slate-400 line-through' : 'text-slate-700'}`}>
        {text}
      </span>
    </div>
  );
};

const ResultView: React.FC<ResultViewProps> = ({ insight, onReset, answers }) => {
  const [showResources, setShowResources] = useState(false);
  const [reflection, setReflection] = useState('');
  const sections = insight.split(/### Section \d: /).filter(s => s.trim() !== '');
  const userEmail = answers.email as string;
  const unsettledAreas = Array.isArray(answers.unsettledArea) ? answers.unsettledArea : [answers.unsettledArea];

  const getBookRecommendations = () => {
    const recommendations: { title: string; author: string; reason: string }[] = [];
    
    const library: Record<string, { title: string; author: string; reason: string }[]> = {
      'Work / Identity': [
        { title: 'Transitions: Making Sense of Life\'s Changes', author: 'William Bridges', reason: 'The gold standard for understanding identity shifts.' },
        { title: 'Designing Your Life', author: 'Bill Burnett & Dave Evans', reason: 'Practical tools for rebuilding a path forward.' },
        { title: 'The Pathless Path', author: 'Paul Millerd', reason: 'For those questioning the traditional career narrative.' }
      ],
      'Relationships (partner or parents)': [
        { title: 'Hold Me Tight', author: 'Dr. Sue Johnson', reason: 'For deepening connection and understanding attachment.' },
        { title: 'Set Boundaries, Find Peace', author: 'Nedra Glover Tawwab', reason: 'Essential for navigating family and partner dynamics.' },
        { title: 'All About Love', author: 'bell hooks', reason: 'A profound look at how we relate to ourselves and others.' }
      ],
      'Friendship': [
        { title: 'Platonic: How the Science of Attachment Can Help You Make—and Keep—Friends', author: 'Dr. Marisa G. Franco', reason: 'The definitive modern guide to adult friendship.' },
        { title: 'Big Friendship', author: 'Aminatou Sow & Ann Friedman', reason: 'A tribute to the complexities of long-term bonds.' }
      ],
      'Family or Parenting': [
        { title: 'The Book You Wish Your Parents Had Read', author: 'Philippa Perry', reason: 'Navigating family patterns with empathy.' },
        { title: 'Parenting from the Inside Out', author: 'Daniel J. Siegel', reason: 'Understanding how your past affects your parenting.' }
      ],
      'Loss or Grief': [
        { title: "It's OK That You're Not OK", author: 'Megan Devine', reason: 'A compassionate, non-clinical approach to grief.' },
        { title: 'The Wild Edge of Sorrow', author: 'Francis Weller', reason: 'For understanding grief as a sacred communal process.' },
        { title: 'Year of Magical Thinking', author: 'Joan Didion', reason: 'A classic exploration of the internal world of loss.' }
      ],
      'Success or Plateau': [
        { title: 'The Second Mountain', author: 'David Brooks', reason: 'For when "success" no longer feels like enough.' },
        { title: 'Essentialism: The Disciplined Pursuit of Less', author: 'Greg McKeown', reason: 'Refining your focus during a plateau.' },
        { title: 'Falling Upward', author: 'Richard Rohr', reason: 'A spiritual perspective on the second half of life.' }
      ],
      'Something I can’t quite name': [
        { title: 'When Things Fall Apart', author: 'Pema Chödrön', reason: 'Finding ground when everything feels groundless.' },
        { title: 'The Quaking of America', author: 'Resmaa Menakem', reason: 'For understanding the somatic/body weight of change.' },
        { title: 'The Wisdom of No Escape', author: 'Pema Chödrön', reason: 'Learning to say "yes" to the present moment.' }
      ]
    };

    unsettledAreas.forEach(area => {
      if (area && library[area]) {
        recommendations.push(...library[area]);
      }
    });

    // Handle generic or missing areas
    if (recommendations.length === 0) {
      recommendations.push({ title: 'Life Is in the Transitions', author: 'Bruce Feiler', reason: 'A modern study of how to navigate "lifequakes."' });
    }

    // De-duplicate and limit to 5 most relevant
    const unique = Array.from(new Set(recommendations.map(r => r.title)))
      .map(title => recommendations.find(r => r.title === title)!);
    
    return unique.slice(0, 5);
  };

  const renderFormattedText = (text: string, isChecklist: boolean = false) => {
    const cleanedText = text.replace(/—/g, ',');
    const lines = cleanedText.split('\n');

    if (isChecklist) {
      return (
        <div className="mt-4">
          {lines
            .filter(line => line.trim().startsWith('- '))
            .map((line, i) => (
              <ChecklistItem key={i} text={line.substring(2)} />
            ))}
        </div>
      );
    }

    return lines.map((line, i) => {
      const trimmed = line.trim();
      if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
        return <li key={i} className="ml-4 list-disc mb-2 text-slate-600">{trimmed.substring(2)}</li>;
      }
      if (trimmed === '') return <div key={i} className="h-2"></div>;
      return <p key={i} className="mb-4 leading-relaxed text-slate-600 text-lg">{line}</p>;
    });
  };

  const handleSendReflection = () => {
    const subject = encodeURIComponent("reflections from Between Chapters' intake");
    const body = encodeURIComponent(`My Reflection:\n\n${reflection}\n\n---\nCompleted via Between Chapters`);
    window.location.href = `mailto:${userEmail}?subject=${subject}&body=${body}`;
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-16 animate-in fade-in zoom-in-95 duration-1000">
      <header className="mb-16 text-center">
        <span className="text-[10px] font-bold text-[#0ea5e9] uppercase tracking-[0.4em] mb-4 block">
          Your Reflection Summary
        </span>
        <h1 className="text-4xl md:text-6xl font-serif text-black italic">
          Between Chapters
        </h1>
      </header>

      <div className="space-y-12 mb-20">
        {sections.map((section, idx) => {
          const lines = section.trim().split('\n');
          const title = lines[0].replace(/—/g, ',');
          const content = lines.slice(1).join('\n');
          const is90DayPlan = title.toLowerCase().includes('90-day');

          return (
            <section key={idx} className="bg-white rounded-[2rem] p-10 md:p-14 shadow-xl shadow-slate-100 border border-slate-50 transition-all">
              <h2 className="text-2xl md:text-3xl font-serif text-black mb-8 border-b border-slate-100 pb-4">
                {title}
              </h2>
              <div className="prose prose-slate prose-lg max-w-none">
                {renderFormattedText(content, is90DayPlan)}
              </div>
            </section>
          );
        })}
      </div>

      <div className="bg-slate-50 rounded-[2.5rem] p-10 md:p-14 text-center border border-slate-100 shadow-inner mb-12">
        <h3 className="text-2xl font-serif text-black mb-6">Ready to navigate this with more support?</h3>
        
        <div className="flex flex-wrap justify-center gap-4 mb-10">
          <button 
            onClick={() => setShowResources(!showResources)}
            className="px-8 py-4 bg-white border border-slate-200 rounded-full text-slate-700 font-medium hover:border-[#0ea5e9] hover:text-[#0ea5e9] transition-all shadow-sm"
          >
            {showResources ? "Hide Resources" : "Explore Self-Guided Path"}
          </button>
          
          <a 
            href={`mailto:aazlogan@gmail.com?subject=Interested in Research Group - Between Chapters&body=I have completed my reflection and would like to learn more about joining a research group for my email: ${userEmail}`}
            className="px-8 py-4 bg-white border border-slate-200 rounded-full text-slate-700 font-medium hover:border-[#0ea5e9] hover:text-[#0ea5e9] transition-all shadow-sm"
          >
            Join a Research Group
          </a>
          
          <a 
            href="https://calendly.com/azlogan/45mins" 
            target="_blank" 
            rel="noopener noreferrer"
            className="px-8 py-4 bg-black text-white rounded-full hover:bg-[#0ea5e9] transition-all flex items-center shadow-lg transform hover:scale-105"
          >
            <span>Supported Conversations</span>
            <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </a>
        </div>

        {showResources && (
          <div className="text-left bg-white rounded-2xl p-8 border border-slate-200 animate-in fade-in slide-in-from-top-4 mb-8">
            <h4 className="font-bold text-black mb-6 uppercase tracking-wider text-xs border-b border-slate-100 pb-2">Curated Self-Guided Resources</h4>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div className="space-y-8">
                <div>
                  <p className="font-serif italic text-lg mb-4 text-black underline decoration-sky-100 underline-offset-4">Article & Video Deep-Dives</p>
                  <ul className="space-y-3 text-sm">
                    <li>
                      <a href="https://hbr.org/2022/03/how-to-navigate-a-big-life-transition" target="_blank" className="group block">
                        <span className="text-[#0ea5e9] group-hover:underline font-medium">• HBR: Navigating Big Life Transitions</span>
                        <p className="text-slate-400 text-xs ml-3 mt-0.5">A practical framework for organizational and personal change.</p>
                      </a>
                    </li>
                    <li>
                      <a href="https://hbr.org/topic/managing-yourself" target="_blank" className="group block">
                        <span className="text-[#0ea5e9] group-hover:underline font-medium">• HBR: Managing Yourself Series</span>
                        <p className="text-slate-400 text-xs ml-3 mt-0.5">High-performance strategies for internal leadership.</p>
                      </a>
                    </li>
                    <li>
                      <a href="https://www.coursera.org/learn/the-science-of-well-being" target="_blank" className="group block">
                        <span className="text-[#0ea5e9] group-hover:underline font-medium">• Yale: The Science of Well-Being</span>
                        <p className="text-slate-400 text-xs ml-3 mt-0.5">The most popular course in Yale history, free on Coursera.</p>
                      </a>
                    </li>
                    <li>
                      <a href="https://www.udemy.com/courses/personal-development/personal-transformation/?price=price-free" target="_blank" className="group block">
                        <span className="text-[#0ea5e9] group-hover:underline font-medium">• Udemy: Personal Transformation Path</span>
                        <p className="text-slate-400 text-xs ml-3 mt-0.5">A collection of free community-led workshops.</p>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>

              <div>
                <p className="font-serif italic text-lg mb-4 text-black underline decoration-sky-100 underline-offset-4">Recommended Reading for You</p>
                <div className="space-y-5">
                  {getBookRecommendations().map((book, i) => (
                    <div key={i} className="group border-l-2 border-slate-50 pl-4 py-1 hover:border-sky-300 transition-colors">
                      <p className="text-sm font-semibold text-slate-800 group-hover:text-black">{book.title}</p>
                      <p className="text-xs text-slate-500 italic mb-1">by {book.author}</p>
                      <p className="text-[11px] text-slate-400 leading-snug">{book.reason}</p>
                    </div>
                  ))}
                  <div className="bg-sky-50 rounded-xl p-4 mt-6 border border-sky-100">
                    <p className="text-[10px] text-sky-700 uppercase tracking-widest font-bold mb-1">Tailored Selection</p>
                    <p className="text-[10px] text-sky-600 leading-relaxed italic">
                      These titles were selected specifically for your focus on: <span className="font-bold">{unsettledAreas.join(', ')}</span>.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Final Reflection Space */}
      <section className="bg-white rounded-[2rem] p-10 md:p-14 shadow-xl shadow-slate-100 border border-sky-100 mb-12">
        <h2 className="text-2xl md:text-3xl font-serif text-black mb-6">
          Final Reflection
        </h2>
        <p className="text-slate-500 mb-8 leading-relaxed">
          Before you close this chapter of reflection, what is one thing that felt particularly true as you read through your insights? Write it here to send it to your future self.
        </p>
        <textarea
          value={reflection}
          onChange={(e) => setReflection(e.target.value)}
          placeholder="I realized that I have been rushing..."
          className="w-full bg-slate-50 rounded-2xl p-6 border border-slate-100 focus:border-[#0ea5e9] outline-none text-lg text-slate-700 min-h-[150px] transition-all mb-6"
        />
        <button
          onClick={handleSendReflection}
          disabled={!reflection.trim()}
          className={`px-8 py-4 rounded-full font-medium transition-all ${
            reflection.trim() 
            ? 'bg-[#0ea5e9] text-white hover:bg-[#0284c7] shadow-md' 
            : 'bg-slate-100 text-slate-300 cursor-not-allowed'
          }`}
        >
          Send to my inbox
        </button>
      </section>

      <div className="text-center py-12">
        <button
          onClick={onReset}
          className="text-slate-400 hover:text-[#0ea5e9] font-medium transition-colors text-sm uppercase tracking-widest"
        >
          Begin a New Reflection
        </button>
      </div>
    </div>
  );
};

export default ResultView;
