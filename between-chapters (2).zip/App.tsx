
import React, { useState } from 'react';
import WelcomeView from './components/WelcomeView';
import QuestionCard from './components/QuestionCard';
import LoadingScreen from './components/LoadingScreen';
import ResultView from './components/ResultView';
import { QUESTIONS } from './constants';
import { AppState, UserAnswers } from './types';
import { getTransitionInsight } from './services/geminiService';

const App: React.FC = () => {
  const [currentState, setCurrentState] = useState<AppState>(AppState.WELCOME);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<UserAnswers>({});
  const [insight, setInsight] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const handleStart = () => {
    setCurrentState(AppState.SURVEY);
    setCurrentQuestionIndex(0);
    setAnswers({});
    setError(null);
  };

  const handleNext = async (answer: string | string[]) => {
    const currentQuestion = QUESTIONS[currentQuestionIndex];
    const updatedAnswers = { ...answers, [currentQuestion.id]: answer };
    setAnswers(updatedAnswers);

    if (currentQuestionIndex < QUESTIONS.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      setCurrentState(AppState.LOADING);
      try {
        const result = await getTransitionInsight(updatedAnswers);
        setInsight(result);
        setCurrentState(AppState.RESULT);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } catch (err) {
        setError("The insights are taking a quiet moment. Please try again shortly.");
        setCurrentState(AppState.WELCOME);
      }
    }
  };

  const handleBack = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    } else {
      setCurrentState(AppState.WELCOME);
    }
  };

  const renderContent = () => {
    switch (currentState) {
      case AppState.WELCOME:
        return (
          <div className="animate-in fade-in duration-1000">
            {error && (
              <div className="bg-slate-50 text-slate-900 p-6 rounded-2xl text-center mb-8 max-w-md mx-auto border border-slate-100 italic">
                {error}
              </div>
            )}
            <WelcomeView onStart={handleStart} />
          </div>
        );
      case AppState.SURVEY:
        return (
          <QuestionCard
            question={QUESTIONS[currentQuestionIndex]}
            onNext={handleNext}
            onBack={handleBack}
            currentIndex={currentQuestionIndex}
            totalQuestions={QUESTIONS.length}
          />
        );
      case AppState.LOADING:
        return <LoadingScreen />;
      case AppState.RESULT:
        return <ResultView insight={insight} answers={answers} onReset={() => setCurrentState(AppState.WELCOME)} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-sky-100 relative">
      <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-slate-50 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-20%] right-[-10%] w-[70%] h-[70%] bg-slate-50 rounded-full blur-[140px]"></div>
      </div>

      <nav className="p-8 md:px-12 flex justify-center items-center">
        <div 
          className="flex flex-col items-center cursor-pointer group"
          onClick={() => setCurrentState(AppState.WELCOME)}
        >
          <span className="font-serif text-2xl text-black tracking-tight italic group-hover:text-[#0ea5e9] transition-colors duration-500">
            Between Chapters
          </span>
          <div className="h-[1px] w-0 group-hover:w-full bg-[#0ea5e9] transition-all duration-700"></div>
        </div>
      </nav>

      <main className="flex-grow flex items-center justify-center py-8">
        {renderContent()}
      </main>
      
      <footer className="p-12 text-center text-slate-300 text-[10px] uppercase tracking-[0.5em] font-medium">
        THE SPACE BETWEEN, {new Date().getFullYear()}
      </footer>
    </div>
  );
};

export default App;
