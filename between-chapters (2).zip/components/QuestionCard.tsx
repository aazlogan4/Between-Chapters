
import React, { useState, useEffect } from 'react';
import { Question } from '../types';

interface QuestionCardProps {
  question: Question;
  onNext: (answer: string | string[]) => void;
  onBack: () => void;
  currentIndex: number;
  totalQuestions: number;
}

const QuestionCard: React.FC<QuestionCardProps> = ({ 
  question, 
  onNext, 
  onBack, 
  currentIndex, 
  totalQuestions 
}) => {
  const [inputValue, setInputValue] = useState('');
  const [selectedOptions, setSelectedOptions] = useState<string[]>([]);

  useEffect(() => {
    setInputValue('');
    setSelectedOptions([]);
  }, [currentIndex]);

  const progress = ((currentIndex + 1) / totalQuestions) * 100;

  const handleChoice = (option: string) => {
    if (question.type === 'choice') {
      onNext(option);
    } else if (question.type === 'multi-choice') {
      setSelectedOptions(prev => 
        prev.includes(option) ? prev.filter(o => o !== option) : [...prev, option]
      );
    }
  };

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (question.type === 'multi-choice') {
      if (selectedOptions.length > 0) onNext(selectedOptions);
    } else {
      if (inputValue.trim()) onNext(inputValue);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-6 py-12">
      <div className="mb-12">
        <div className="flex justify-between items-center mb-4">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.3em]">
            Step {currentIndex + 1} of {totalQuestions}
          </span>
          <div className="h-1 w-32 bg-slate-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-[#0ea5e9] transition-all duration-1000 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      <div className="min-h-[400px]">
        <h2 className="text-3xl md:text-4xl font-serif text-black mb-2 leading-snug">
          {question.label}
        </h2>
        {question.type === 'multi-choice' && (
          <p className="text-slate-400 text-sm mb-10 italic">Select all that apply</p>
        )}
        {question.type === 'text' && <div className="mb-10"></div>}
        {question.type === 'choice' && <div className="mb-10"></div>}

        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          {(question.type === 'choice' || question.type === 'multi-choice') ? (
            <div className="grid grid-cols-1 gap-3 max-h-[50vh] overflow-y-auto selection-area pr-2">
              {question.options?.map((option) => {
                const isSelected = selectedOptions.includes(option);
                return (
                  <button
                    key={option}
                    onClick={() => handleChoice(option)}
                    className={`text-left w-full px-8 py-5 rounded-2xl border-2 transition-all duration-300 text-lg ${
                      isSelected 
                        ? 'border-[#0ea5e9] bg-sky-50 text-black ring-1 ring-sky-100' 
                        : 'border-slate-100 bg-white hover:border-slate-300 hover:shadow-sm text-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{option}</span>
                      {question.type === 'multi-choice' && (
                        <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${
                          isSelected ? 'bg-[#0ea5e9] border-[#0ea5e9]' : 'border-slate-300'
                        }`}>
                          {isSelected && (
                            <svg className="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                        </div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <textarea
                autoFocus
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder={question.placeholder}
                rows={4}
                className="w-full bg-transparent border-b border-slate-200 focus:border-[#0ea5e9] outline-none text-xl md:text-2xl py-4 transition-colors duration-300 text-black mb-12 resize-none"
                required
              />
            </form>
          )}

          <div className="mt-12 flex justify-between items-center">
            <button
              onClick={onBack}
              className={`text-slate-400 hover:text-black text-sm font-medium transition-colors flex items-center ${
                currentIndex === 0 ? 'invisible' : 'visible'
              }`}
            >
              <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              Previous
            </button>

            {(question.type === 'multi-choice' || question.type === 'text') && (
              <button
                onClick={handleSubmit}
                disabled={question.type === 'multi-choice' ? selectedOptions.length === 0 : !inputValue.trim()}
                className={`group px-10 py-4 rounded-full font-medium transition-all flex items-center space-x-2 ${
                  (question.type === 'multi-choice' ? selectedOptions.length > 0 : inputValue.trim())
                    ? 'bg-black text-white shadow-lg hover:bg-[#0ea5e9] transform hover:-translate-y-0.5' 
                    : 'bg-slate-100 text-slate-300 cursor-not-allowed'
                }`}
              >
                <span>Continue</span>
                <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuestionCard;
