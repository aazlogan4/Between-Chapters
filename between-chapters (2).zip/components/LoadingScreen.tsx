
import React, { useEffect, useState } from 'react';

const LoadingScreen: React.FC = () => {
  const [messageIndex, setMessageIndex] = useState(0);
  const messages = [
    "Analyzing your reflection data...",
    "Synthesizing transition patterns...",
    "Mapping your 90-day personal pathway...",
    "Identifying key identity shifts...",
    "Finalizing your tailored insights..."
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % messages.length);
    }, 2000);
    return () => clearInterval(interval);
  }, [messages.length]);

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-6">
      <div className="w-16 h-16 border-2 border-slate-100 border-t-[#0ea5e9] rounded-full animate-spin mb-8"></div>
      <p className="text-xl font-serif text-slate-600 animate-pulse transition-all duration-1000">
        {messages[messageIndex]}
      </p>
    </div>
  );
};

export default LoadingScreen;
