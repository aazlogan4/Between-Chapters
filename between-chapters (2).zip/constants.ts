
import { Question } from './types';

export const QUESTIONS: Question[] = [
  {
    id: 'email',
    label: 'To begin, what is your email address?',
    type: 'text',
    placeholder: 'email@example.com'
  },
  {
    id: 'unsettledArea',
    label: 'Which area of life feels most unsettled right now?',
    type: 'multi-choice',
    options: [
      'Work / Identity',
      'Relationships (partner or parents)',
      'Friendship',
      'Family or Parenting',
      'Loss or Grief',
      'Success or Plateau',
      'Something I can’t quite name'
    ]
  },
  {
    id: 'transitionNature',
    label: 'Does this transition feel:',
    type: 'choice',
    options: [
      'Chosen',
      'Imposed',
      'A slow realization',
      'A sudden shift'
    ]
  },
  {
    id: 'emotions',
    label: 'What emotions show up most often lately?',
    type: 'multi-choice',
    options: [
      'Restlessness',
      'Sadness',
      'Irritation',
      'Numbness',
      'Hope mixed with fear'
    ]
  },
  {
    id: 'talkingTo',
    label: 'Who do you currently talk to about this?',
    type: 'choice',
    options: [
      'No one',
      'A partner',
      'Friends (but not deeply)',
      'A small trusted circle'
    ]
  },
  {
    id: 'hardestToSay',
    label: 'What feels hardest to say out loud?',
    type: 'text',
    placeholder: 'Try to be as honest as you can...'
  },
  {
    id: 'afraidOfLosing',
    label: 'What are you most afraid of losing right now?',
    type: 'text',
    placeholder: 'Stability, status, a version of yourself...'
  },
  {
    id: 'underusedPart',
    label: 'What part of yourself feels underused or unseen?',
    type: 'text',
    placeholder: 'A skill, a side of your personality...'
  },
  {
    id: 'progressVision',
    label: 'When you imagine 6 months from now, what would feel like progress?',
    type: 'text',
    placeholder: 'How would your days feel different?'
  },
  {
    id: 'uncertaintyResponse',
    label: 'How do you usually respond to uncertainty?',
    type: 'multi-choice',
    options: [
      'Analyze',
      'Distract',
      'Withdraw',
      'Stay busy',
      'Talk it through'
    ]
  },
  {
    id: 'resistedSupport',
    label: 'What kind of support do you tend to resist—even if it helps?',
    type: 'text',
    placeholder: 'Asking for help, vulnerability, taking time off...'
  }
];
